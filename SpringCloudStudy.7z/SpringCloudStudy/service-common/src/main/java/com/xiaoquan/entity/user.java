package com.xiaoquan.entity;
import lombok.Data;
@Data
public class user {
    int uid;
    String name;
    int age;
    String email;
}
