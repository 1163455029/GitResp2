package com.xiaoquan.controller;
import com.xiaoquan.eneity.user;
import com.xiaoquan.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class UserController {
    @Autowired
    UserService service;
    //这里以RESTFul风格为例
    @RequestMapping("/user/{uid}")
    public user findUserById(@PathVariable("uid") int uid){
        return service.getUserById(uid);
    }

}
