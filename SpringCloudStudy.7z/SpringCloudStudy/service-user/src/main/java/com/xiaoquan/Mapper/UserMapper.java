package com.xiaoquan.Mapper;

import com.xiaoquan.eneity.user;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {
    @Select("select * from db_user where uid = #{uid}")
    user getUserById(int uid);

}
