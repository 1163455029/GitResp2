package com.xiaoquan.service;

import com.xiaoquan.eneity.user;


public interface UserService {
    user getUserById(int uid);
}
