package com.xiaoquan.eneity;

import lombok.Data;

@Data
public class user {
    int uid;
    String name;
    int age;
    String email;
}
