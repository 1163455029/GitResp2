package com.xiaoquan.service;
import com.xiaoquan.Mapper.BookMapper;
import com.xiaoquan.entity.Book;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
@Service
public class BookServiceImpl implements BookService{
    @Resource
    private BookMapper bookMapper;
    @Override
    public Book getBookById(int bid) {
        return bookMapper.getBookById(bid);
    }
}
