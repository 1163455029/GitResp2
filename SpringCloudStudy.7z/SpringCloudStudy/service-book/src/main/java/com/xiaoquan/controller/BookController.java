package com.xiaoquan.controller;
import com.xiaoquan.entity.Book;
import com.xiaoquan.service.BookService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class BookController {
    @Resource
    private BookService bookService;
    @RequestMapping("/book/{bid}")
    Book findBookByid(@PathVariable("bid") int bid){
        return bookService.getBookById(bid);
    }
}