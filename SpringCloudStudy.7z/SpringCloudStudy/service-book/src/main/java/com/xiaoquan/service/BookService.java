package com.xiaoquan.service;
import com.xiaoquan.entity.Book;
public interface BookService {
    Book getBookById(int bid);

}
