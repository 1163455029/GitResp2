package com.xiaoquan.service;
import com.xiaoquan.entity.UserBorrowDetail;
public interface BorrowService {
    UserBorrowDetail getUserBorrowDetailByUid(int uid);
}